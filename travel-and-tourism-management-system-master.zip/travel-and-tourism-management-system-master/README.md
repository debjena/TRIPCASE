The objective of the Travel and Tourism Management System project is to develop a system that automates the processes and activities of a travel and tourism agency. The purpose is to design a system using which one can perform all operations related to traveling and sight-seeing. The system allows one to easily access the relevant information and make necessary travel arrangements. Users can decide about places they want to visit and make bookings online for travel and accommodation.

![Travel and Tourism management System1](https://user-images.githubusercontent.com/81694983/120067410-17fe4080-c099-11eb-8f50-271472c619b2.png)
![Travel and Tourism management System2](https://user-images.githubusercontent.com/81694983/120067446-40863a80-c099-11eb-9b52-8d7444bc0cc4.png)
![Travel and Tourism management System3](https://user-images.githubusercontent.com/81694983/120067474-6e6b7f00-c099-11eb-9f19-699fce65663a.png)
# travel-and-tourism-management-system
